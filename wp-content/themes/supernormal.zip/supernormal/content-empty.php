<?php

/**
 * @package WordPress
 * @subpackage Supernormal
 * @since Supernormal 1.0
 */
?>
<div class="empty-wrap">
    <div class="empty-graphic"></div>
    <p>현재 글이 없습니다.</p>
</div>