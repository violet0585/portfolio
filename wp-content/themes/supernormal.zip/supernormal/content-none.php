<?php

/**
 * @package WordPress
 * @subpackage Supernormal
 * @since Supernormal 1.0
 */
?>

<!-- 검색결과 없음 -->
<section class="no-results not-found">
    <h2>검색 결과가 없습니다.</h2>
    <p>다른 키워드로 검색해보세요.</p>
    <?php get_search_form(); ?>
</section><!-- .no-results -->