<?php

/**
 * @package WordPress
 * @subpackage Supernormal
 * @since Supernormal 1.0
 */

/*
 * Template Name: 메인 페이지
 */
get_header(); ?>

<?php get_template_part('main-slider'); ?>
<section class="work-section">
    <div class="container">
        <div class="category-title-wrap">
            <h2 class="category-title">Portfolio</h2>
            <a class="button line-button" href="<?php echo esc_url(home_url('/work')); ?>"">Show More</a>
        </div>
        <div class=" row">
                <!-- 배열에 대한 정의 -->
                <?php
                if (wp_is_mobile()) {
                    $work = new WP_Query(
                        array(
                            'posts_per_page' => 4,
                            'post_type' => 'work',
                            'order' => 'date',
                        )
                    );
                } else {
                    $work = new WP_Query(
                        array(
                            'posts_per_page' => 12,
                            'post_type' => 'work',
                            'order' => 'date',
                        )
                    );
                } ?>
                <!-- if문 : 해당 배열 안에 포스트 데이터를 가지고 있는지? -->
                <?php if ($work->have_posts()): ?>
                    <!-- while문 : 해당 배열 안에 포스트를 반복해서 불러오기 -->
                    <?php while ($work->have_posts()):
                        $work->the_post(); ?>
                        <!-- Start : 이 안에 코드 형식으로 출력 -->
                        <div class="col-4">
                            <?php get_template_part('content-work'); ?>
                        </div>
                        <!-- End : 이 안에 코드 형식으로 출력 -->
                    <?php endwhile; ?>

                <?php else: ?>
                    <!-- if문 : 해당 배열 안에 포스트 데이터를 가지고 있지 않을 때 해당 코드 실행 -->
                    <?php get_template_part('content', 'empty'); ?>
                <?php endif; ?>

                <?php the_posts_pagination(array('prev_text' => '', 'next_text' => '')); ?>
        </div>
    </div>
</section>

<section class="about-section">
    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="img-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/img/about-me.png" alt="">
                </div>
            </div>
            <div class="col-6">
                <div class="text-wrap">
                    <h2>Hi! I'am {username}</h2>
                    <p>I am product designer specialized in UX/UI, currently living in South Korea.
                        Where I have been working as a freelancer for about 8 years.</p>
                    <a class="button" href="<?php echo esc_url(home_url('/about')); ?>">Learn more about me</a>
                </div>
            </div>



        </div>
    </div>
</section>
<section class="marquee-section">
    <div class="marquee">
        <div class="marquee__content">
            <ul class="list-inline">
                <li>UI/UX Design</li>
                <li>Brand Experiance</li>
                <li>Content Design</li>
                <li>Development</li>
            </ul>
            <ul class="list-inline">
                <li>UI/UX Design</li>
                <li>Brand Experiance</li>
                <li>Content Design</li>
                <li>Development</li>
            </ul>
            <ul class="list-inline">
                <li>UI/UX Design</li>
                <li>Brand Experiance</li>
                <li>Content Design</li>
                <li>Development</li>
            </ul>
        </div>
    </div>
</section>
<section class="section-blog">
    <div class="container">
        <div class="category-title-wrap">
            <h2 class="category-title">디자인 블로그</h2>
            <a class="button line-button" href="<?php echo esc_url(home_url('/blog')); ?>">Show More</a>
        </div>
        <div class="row">
            <!-- 배열에 대한 정의 -->
            <?php
            $args = array(
                // 'posts_per_page' => -1, //수 제한 없음
                'posts_per_page' => 4,
                // 표시할 항목
                'category_name' => 'design',
                //특정 카테고리 리스트 원할때 
                // 'author_name' => 'admin', //특정 편집자 글만 보이기 원할때
                // 'order' => 'DESC', //오름차순, 내림차순은 DESC
                'orderby' => 'rand',
                //랜덤
                'post_type' => 'post' //포스트 타입 불러오기 / page로 하면 페이지를 불러옴
            );
            $query = new WP_Query($args);
            ?>




            <!-- if문 : 해당 배열 안에 포스트 데이터를 가지고 있는지? -->
            <?php if ($query->have_posts()): ?>



                <!-- while문 : 해당 배열 안에 포스트를 반복해서 불러오기 -->
                <?php while ($query->have_posts()):
                    $query->the_post(); ?>


                    <!-- Start : 이 안에 코드 형식으로 출력 -->
                    <div class="col-3">
                        <?php get_template_part('content'); ?>
                    </div>
                    <!-- End : 이 안에 코드 형식으로 출력 -->
                <?php endwhile; ?>

            <?php else: ?>

                <!-- if문 : 해당 배열 안에 포스트 데이터를 가지고 있지 않을 때 해당 코드 실행 -->
                <?php get_template_part('content', 'empty'); ?>


            <?php endif; ?>







            <?php the_posts_pagination(array('prev_text' => '', 'next_text' => '')); ?>

        </div>
    </div>
</section>

<section>
    <div class="container">
        <?php echo do_shortcode('[instagram-feed feed=1]'); ?>
    </div>
</section>


<?php get_footer(); ?>